import React from 'react';
export const FileCard=({children}:any)=><main className="file-card">{children}</main>;
export const Header=({title,fact,intro}:any)=><header><h1>{title}</h1><p className="fact">{fact}</p><p className="intro">{intro}</p></header>;
export const Group=({label,heading,children}:any)=><section className="file-group"><p className="group-label">{label}</p>{heading&&<h2>{typeof heading==='string'?heading:label}</h2>}{children}</section>;
export const Closing=({children}:any)=><footer>{children}</footer>;
export const ChoiceRow=({label,options,value,onChange}:any)=><div className="file-control" role="group" aria-label={label}><span className="file-control-label">{label}</span><div className="file-choice-row">{options.map((o:any)=><FileButton key={o.value} selected={value===o.value} onClick={()=>onChange(o.value)}>{o.label}</FileButton>)}</div></div>;
export const FileButton=({selected,onClick,children}:any)=><button className="file-button" aria-pressed={!!selected} onClick={onClick}>{children}</button>;
export const Callout=({title,children}:any)=><aside className="file-callout"><strong>{title}</strong><div>{children}</div></aside>;
export const TextLink=({href,children}:any)=><a href={href} target="_blank" rel="noopener noreferrer">{children}</a>;
