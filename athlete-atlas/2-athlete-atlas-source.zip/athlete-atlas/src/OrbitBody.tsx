import React,{useEffect,useRef,useState} from 'react';
import {regions} from './data';
type Part={id:string,p:number[],s:number[],r?:number};
const parts:Part[]=[{id:'head',p:[0,2.45,0],s:[.27,.36,.25]},{id:'head',p:[0,2.06,0],s:[.14,.18,.14]}];
for(const side of [-1,1]){
 const add=(id:string,p:number[],s:number[],r=0)=>parts.push({id,p:[p[0]*side,p[1],p[2]],s,r:r*side});
 add('shoulder',[.56,1.85,0],[.23,.25,.24]);add('upperarm',[.72,1.39,0],[.155,.39,.17],.15);add('elbow',[.79,.96,0],[.14,.13,.15]);add('hand',[.98,.16,.02],[.13,.24,.09],.1);
 add('forearm',[.88,.59,0],[.12,.32,.12],.13);add('chest',[.27,1.72,.12],[.28,.3,.18]);add('chest',[.3,1.65,-.1],[.28,.39,.16]);
 add('back',[.22,.99,-.09],[.22,.35,.18]);add('hip',[.26,.65,0],[.25,.27,.22]);add('thigh',[.29,.04,.02],[.23,.5,.24]);add('knee',[.3,-.48,.05],[.18,.17,.17]);add('lowerleg',[.3,-.98,-.015],[.18,.41,.19]);add('ankle',[.3,-1.46,0],[.11,.18,.11]);add('foot',[.3,-1.69,.14],[.15,.12,.29]);
 for(let i=0;i<3;i++)add('chest',[.13,1.4-i*.2,.15],[.115,.085,.09]);
}
const vs=`attribute vec3 a;attribute vec3 n;uniform vec3 p;uniform vec3 s;uniform float rot;uniform float yaw;uniform float pitch;uniform float aspect;uniform float zoom;varying vec3 normal;void main(){mat3 rz=mat3(cos(rot),sin(rot),0.,-sin(rot),cos(rot),0.,0.,0.,1.);mat3 ry=mat3(cos(yaw),0.,-sin(yaw),0.,1.,0.,sin(yaw),0.,cos(yaw));mat3 rx=mat3(1.,0.,0.,0.,cos(pitch),sin(pitch),0.,-sin(pitch),cos(pitch));mat3 view=rx*ry;vec3 pos=view*(rz*(a*s)+p-vec3(0.,.53,0.));normal=normalize(view*rz*(n/s));gl_Position=vec4(pos.x/(3.*aspect)*zoom,pos.y/3.*zoom,-pos.z/9.,1.);}`;
const fs=`precision mediump float;uniform vec3 color;uniform bool picking;varying vec3 normal;void main(){float light=.42+.58*max(0.,dot(normalize(normal),normalize(vec3(-.7,1.,1.5))));gl_FragColor=vec4(picking?color:color*light,1.);}`;
export function OrbitBody({counts,selected,onSelect,skeleton,motion,available}:any){
 const canvas=useRef<HTMLCanvasElement>(null),props=useRef<any>({}),[error,setError]=useState(''),[zoom,setZoom]=useState(1);
 props.current={counts,selected,onSelect,skeleton,motion,available,zoom};
 useEffect(()=>{
 const c=canvas.current!;const gl=c.getContext('webgl',{antialias:true,preserveDrawingBuffer:true});if(!gl){setError('3D graphics are unavailable on this device. Switch back to the front or back diagram.');return}
 function shader(type:number,src:string){const sh=gl!.createShader(type)!;gl!.shaderSource(sh,src);gl!.compileShader(sh);if(!gl!.getShaderParameter(sh,gl!.COMPILE_STATUS))throw new Error('Shader failed');return sh}
 const prog=gl.createProgram()!;gl.attachShader(prog,shader(gl.VERTEX_SHADER,vs));gl.attachShader(prog,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(prog);gl.useProgram(prog);
 const vertices:number[]=[],normals:number[]=[];const v=(a:number,b:number)=>[Math.sin(a)*Math.cos(b),Math.cos(a),Math.sin(a)*Math.sin(b)];
 for(let i=0;i<22;i++)for(let j=0;j<28;j++){const a=i*Math.PI/22,b=j*Math.PI*2/28,da=Math.PI/22,db=Math.PI*2/28;for(const x of [v(a,b),v(a+da,b),v(a+da,b+db),v(a,b),v(a+da,b+db),v(a,b+db)]){vertices.push(...x);normals.push(...x)}}
 for(const [name,data] of [['a',vertices],['n',normals]] as any){const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);const loc=gl.getAttribLocation(prog,name);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,3,gl.FLOAT,false,0,0)}
 const u=(name:string)=>gl.getUniformLocation(prog,name);gl.enable(gl.DEPTH_TEST);
 let yaw=.2,pitch=-.04,frame=0,last=performance.now(),drag:any=null,moved=false,dead=false;
 function draw(pick=false){if(dead)return;const pr=props.current;const rect=c.getBoundingClientRect();const d=Math.min(window.devicePixelRatio||1,2);if(c.width!==Math.round(rect.width*d)||c.height!==Math.round(rect.height*d)){c.width=Math.round(rect.width*d);c.height=Math.round(rect.height*d)}gl!.viewport(0,0,c.width,c.height);gl!.clearColor(pick?0:.985,pick?0:.981,pick?0:.974,1);gl!.clear(gl!.COLOR_BUFFER_BIT|gl!.DEPTH_BUFFER_BIT);gl!.uniform1f(u('yaw'),yaw);gl!.uniform1f(u('pitch'),pitch);gl!.uniform1f(u('aspect'),c.width/c.height);gl!.uniform1f(u('zoom'),pr.zoom);gl!.uniform1i(u('picking'),pick?1:0);const max=Math.max(1,...Object.values(pr.counts).map(Number));
 parts.forEach((part,index)=>{let color=[.75,.68,.62];const n=pr.counts[part.id]||0;if(pr.available&&n){const t=n/max;color=[.94-.18*t,.71-.6*t,.63-.52*t]}else if(!pr.available)color=[.78,.77,.74];if(part.id===pr.selected&&!pick)color=color.map(x=>Math.min(1,x*1.13));if(pick)color=[(index+1)/255,0,0];gl!.uniform3fv(u('color'),color);gl!.uniform3fv(u('p'),part.p);gl!.uniform3fv(u('s'),pr.skeleton&&part.id!=='head'&&part.id!=='foot'?part.s.map((x,i)=>i===1?x:x*.43):part.s);gl!.uniform1f(u('rot'),part.r||0);gl!.drawArrays(gl!.TRIANGLES,0,vertices.length/3)});
 }
 const down=(e:PointerEvent)=>{drag=[e.clientX,e.clientY];moved=false;c.setPointerCapture(e.pointerId)};
 const move=(e:PointerEvent)=>{if(!drag)return;const dx=e.clientX-drag[0],dy=e.clientY-drag[1];if(Math.abs(dx)+Math.abs(dy)>2)moved=true;yaw+=dx*.012;pitch=Math.max(-.7,Math.min(.7,pitch+dy*.008));drag=[e.clientX,e.clientY]};
 const up=(e:PointerEvent)=>{drag=null;if(moved)return;draw(true);const r=c.getBoundingClientRect(),pixel=new Uint8Array(4);gl!.readPixels(Math.floor((e.clientX-r.left)*c.width/r.width),Math.floor((r.bottom-e.clientY)*c.height/r.height),1,1,gl!.RGBA,gl!.UNSIGNED_BYTE,pixel);const p=parts[pixel[0]-1];if(p&&regions.some(r=>r.id===p.id))props.current.onSelect(p.id);draw()};
 const key=(e:KeyboardEvent)=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();yaw+=e.key==='ArrowLeft'?-.13:e.key==='ArrowRight'?.13:0;pitch=Math.max(-.7,Math.min(.7,pitch+(e.key==='ArrowUp'?-.08:e.key==='ArrowDown'?.08:0)))}};
 c.addEventListener('pointerdown',down);c.addEventListener('pointermove',move);c.addEventListener('pointerup',up);c.addEventListener('keydown',key);
 const loop=(now:number)=>{const dt=Math.min(.05,(now-last)/1000);last=now;if(props.current.motion&&!drag&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches)yaw+=dt*.09;draw();if(!dead)frame=requestAnimationFrame(loop)};frame=requestAnimationFrame(loop);
 return()=>{dead=true;cancelAnimationFrame(frame);c.removeEventListener('pointerdown',down);c.removeEventListener('pointermove',move);c.removeEventListener('pointerup',up);c.removeEventListener('keydown',key);gl.deleteProgram(prog)};
 },[]);
 return <div className="orbit-wrap">{error?<p>{error}</p>:<><canvas ref={canvas} className="orbit-body" tabIndex={0} aria-label="Original procedural 3D anatomy illustration. Drag to rotate, arrow keys to orbit, tap a region to select. Regional buttons below provide a keyboard alternative."/><p className="fine">Drag to orbit · Tap a region · Arrow keys rotate</p><label className="zoom">Zoom <input type="range" min="0.8" max="1.2" step="0.05" value={zoom} onChange={e=>setZoom(Number(e.target.value))}/></label><p className="fine">Original procedural 3D illustration, not a medically accurate model. Bone mode is a simplified structure study. Grey torso/forearm areas are not mapped.</p></>}</div>
}
