import React,{useState} from 'react';
import {FileCard,Header,Group,Closing,ChoiceRow,Callout,TextLink,FileButton} from './ui';
import {sports,sources,regions,demo,evidence} from './data';
import {Anatomy} from './Anatomy';
import {OrbitBody} from './OrbitBody';
import './style.css';
const options=(a:string[])=>a.map(value=>({value,label:value}));
const source=(id:string)=>sources.find(s=>s.id===id)!;
function Cite({id}:{id:string}){const s=source(id);return <TextLink href={s.url}>{s.title}</TextLink>}
export function App(){
 const [sport,setSport]=useState('HYROX'),[role,setRole]=useState('All'),[gender,setGender]=useState('All'),[mode,setMode]=useState('Published cohort'),[history,setHistory]=useState('None selected'),[selected,setSelected]=useState('knee'),[back,setBack]=useState(false),[orbit,setOrbit]=useState(false),[skeleton,setSkeleton]=useState(false),[motion,setMotion]=useState(true),[tab,setTab]=useState('Evidence');
 const synthetic=mode==='Fictional demo';
 const available=synthetic||(sport==='HYROX'&&gender==='All'&&role==='All');
 const rows=demo.filter(x=>x.sport===sport&&(role==='All'||x.role===role)&&(gender==='All'||x.gender===gender));
 const counts=Object.fromEntries(regions.map(r=>[r.id,!available?0:synthetic?rows.filter(x=>x.region===r.id).length:r.n]));
 const total=available?(synthetic?rows.length:63):0;
 const active=regions.find(r=>r.id===selected)!;
 const selectedCount=counts[selected];
 const claims=evidence(sport,selected,history);
 function reset(){setSport('HYROX');setRole('All');setGender('All');setMode('Published cohort');setHistory('None selected');setSelected('knee');setBack(false);setOrbit(false);setSkeleton(false);setMotion(true);setTab('Evidence')}
 return <FileCard>
 <Header title="Understand the athlete. Explore the anatomy." fact="Athlete Atlas / working prototype / 10 activities" intro="Explore regional injury patterns, previous-injury associations and supervised conditioning. This is a research explorer, not an individual injury predictor."/>
 <div className="intro-line"><span className="eyebrow">01 / Set the context</span><button className="reset file-hover-underline" onClick={reset}>Reset explorer</button></div>
 <ChoiceRow label="Sport or activity" options={options(Object.keys(sports))} value={sport} onChange={(s:string)=>{setSport(s);setRole('All')}}/>
 <div className="filter-grid"><ChoiceRow label="Playing role / event type" options={options(['All',...sports[sport]])} value={role} onChange={setRole}/><ChoiceRow label="Gender grouping in demo" options={options(['All','Women','Men','Nonbinary','Not specified'])} value={gender} onChange={setGender}/></div>
 <p className="fine">Coverage starts with cricket, badminton, running and HYROX. The ten activities are a starting set, not a global popularity ranking. Gender identity is not inferred from biological sex in a study.</p>
 <ChoiceRow label="Data behind the colours" options={options(['Published cohort','Fictional demo'])} value={mode} onChange={setMode}/>
 <div className={`data-banner ${synthetic?'demo':''}`} role="status"><strong>{synthetic?'FICTIONAL DEMO DATA':available?'PUBLISHED HYROX COHORT':'NO MATCHED REGIONAL DATA'}</strong><p>{synthetic?`${total} fictional injury events match these filters. These invented records demonstrate the interface only. They are not sports statistics, athlete records or a prediction.`:available?'63 injury episodes among 89 HYROX athletes over 12 weeks, December 2025 to March 2026. All injuries reported by this cohort, not just HYROX-attributed injuries. Counts, not personal risk.':'No curated regional counts match this sport × gender × role selection. Grey means unavailable, not zero injury risk. Use Fictional demo to test filters, or reset to HYROX / All / All for published counts.'}</p>{available&&!synthetic&&<Cite id="hyrox"/>}</div>
 <div className="explorer">
 <section className="map-panel" aria-label="Interactive anatomy">
 <div className="panel-top"><span className="eyebrow">02 / Select a region</span><span className="data-pill">{synthetic?'Fictional':available?'Published':'Unavailable'}</span></div>
 <div className="map-controls"><FileButton selected={!back&&!orbit} onClick={()=>{setBack(false);setOrbit(false)}}>Front</FileButton><FileButton selected={back&&!orbit} onClick={()=>{setBack(true);setOrbit(false)}}>Back</FileButton><FileButton selected={orbit} onClick={()=>setOrbit(!orbit)}>3D orbit</FileButton><FileButton selected={skeleton} onClick={()=>setSkeleton(!skeleton)}>Bones</FileButton><FileButton selected={motion} onClick={()=>setMotion(!motion)}>{motion?'Pause motion':'Play motion'}</FileButton></div>
 {orbit?<OrbitBody counts={counts} selected={selected} onSelect={setSelected} skeleton={skeleton} motion={motion} available={available}/>:<Anatomy counts={counts} selected={selected} onSelect={setSelected} back={back} skeleton={skeleton} motion={motion} available={available}/>}
 <div className="legend"><span>Fewer episodes</span><span className="ramp"/><span>More episodes</span></div>
 <p className="fine">{synthetic?'Fictional counts only. ':available?'Published counts only. ':'No frequency colours. '}Red intensity is relative to the largest count in this view. It is not severity or probability. Both sides share one regional total; no laterality is available. Bones are an illustrative overlay.</p>
 </section>
 <section className="detail-panel" aria-label="Selected region details" aria-live="polite">
 <div className="eyebrow">03 / Region detail</div><h2>{active.name}</h2>
 <div className="count"><strong>{available?selectedCount:'—'}</strong><div>{available?<><b>{synthetic?'fictional':'published'} episodes</b><br/>{selectedCount} of {total} total injury episodes ({(selectedCount/total*100).toFixed(1)}%)</>:<b>No matched frequency data</b>}</div></div>
 {!synthetic&&available&&<p className="fine">55 of 63 episodes fall in mapped regions; 8 other/unspecified episodes are not placed. The denominator includes all 63.</p>}
 <p>{active.examples}</p>
 <ChoiceRow label="Details" options={options(['Evidence','Conditioning','Rehab boundaries'])} value={tab} onChange={setTab}/>
 {tab==='Evidence'&&<div className="tab-content"><h3>Previous-injury scenario</h3><ChoiceRow label="Optional fictional history" options={options(['None selected','Hamstring strain','Ankle sprain','Other injury'])} value={history} onChange={setHistory}/><p className="fine">This scenario changes the reading notes, never the map counts. No personal health records are needed or saved.</p>{claims.map((c,i)=><div className="evidence-note" key={i}><p>{c.text}</p><Cite id={c.source}/></div>)}{history==='Other injury'&&<p>No history-specific model is available for this scenario.</p>}<p className="fine">Selected context: {sport} / {role} / {gender}. Linked research may use sex categories, not gender identity, and may not match the selected role. No gender multiplier or individual probability is applied.</p></div>}
 {tab==='Conditioning'&&<div className="tab-content"><h3>General strengthening examples</h3><p>These are examples from AAOS conditioning guides, not a personalized exercise plan or proof that they prevent every injury in this region.</p>{active.ex.length?<><ul className="exercise-list">{active.ex.map(x=><li key={x}>{x}</li>)}</ul><p>{active.cue}</p><Cite id={active.source}/></>:<p>No generic exercise is suggested here. Head, neck, hand and finger injuries need a condition-specific assessment.</p>}<Callout title="Choose exercises with a clinician" tone="warning">AAOS recommends doctor or physiotherapist supervision. Do not exercise through pain. No sets, loads, return-to-sport dates or personalized progression are prescribed by this prototype.</Callout></div>}
 {tab==='Rehab boundaries'&&<div className="tab-content"><h3>Rehab is diagnosis-specific</h3><p>A region and a previous injury are not enough to choose rehabilitation. A sports clinician should assess the diagnosis, healing stage, symptoms, strength and sport demands before prescribing loading or return to play.</p><ul><li>Use the linked guide as a discussion aid, not clearance.</li><li>Exercise choices and progression depend on the actual injury and current assessment.</li><li>New or worsening symptoms are a reason to stop the activity and seek clinical advice.</li></ul>{active.source&&<Cite id={active.source}/>}<Callout title="Not for diagnosis or urgent decisions" tone="warning">This map cannot assess an acute injury, concussion, fracture or tendon rupture. Use appropriate medical care rather than a heat-map result.</Callout></div>}
 </section></div>
 <Group label="Every region is also a button" heading="Regional counts">
 <div className="region-list">{regions.map(r=><button key={r.id} onClick={()=>setSelected(r.id)} aria-pressed={selected===r.id} className={selected===r.id?'selected':''}><span className="file-hover-underline">{r.name}</span><b>{available?counts[r.id]:'N/A'}</b></button>)}</div><p className="fine">Counts are {synthetic?'fictional demo events':available?'from the single published HYROX cohort':'unavailable for this selection'}. Use keyboard Tab and Enter on the anatomy or these buttons. A small sample is not proof a region is safe.</p>
 </Group>
 <Group label="What this can and cannot do" heading="A useful explorer, not a clinical model">
 <div className="method-grid"><div><h3>Working now</h3><ul><li>Ten activity categories with role or event filters.</li><li>Clickable front/back anatomy, procedural 3D orbit, motion and bone overlay.</li><li>One source-backed HYROX regional count map.</li><li>Separate, plainly labeled fictional filter demo.</li><li>Injury-history evidence notes and conditioning references.</li></ul></div><div><h3>Before individual prediction</h3><ul><li>Consent-governed longitudinal injury and exposure data.</li><li>Consistent outcomes, follow-up window and recurrence definitions.</li><li>A trained model with athlete-level temporal splits.</li><li>External validation, calibration and subgroup evaluation.</li><li>Clinical governance, privacy review and safe deployment.</li></ul></div></div>
 <Callout title="Anatomy prototype limitation" tone="note">This includes original animated 2D regional views and a rotatable procedural 3D illustration. It is not the detailed, medically accurate 3D anatomy in your inspiration links. No Sketchfab or MSD assets were copied. No diagnosis, medical clearance or injury probability is generated.</Callout>
 <p>Research findings and demo records are separate. Changing a sport, role or gender does not manufacture missing clinical evidence. In published mode, unsupported combinations show no map rather than a guessed frequency.</p>
 </Group>
 <Group label="Research and provenance" heading="Read the evidence">
 {sources.map(s=><details className="source-row" key={s.id}><summary>{s.title}</summary><p>{s.note}</p><TextLink href={s.url}>Open source</TextLink></details>)}
 <details className="source-row"><summary>Visual references and asset provenance</summary><p>Original vector and procedural 3D anatomy authored for this prototype. Inspired by the interaction concept only; no models, textures, exercise illustrations or viewer code reused.</p><TextLink href="https://sketchfab.com/3d-models/animated-full-human-body-anatomy-9b0b079953b840bc9a13f524b60041e4">Sketchfab anatomy reference</TextLink><br/><TextLink href="https://www.msdmanuals.com/home/multimedia/3dmodel/muscular-system">MSD muscular-system reference</TextLink></details>
 </Group>
 <Closing>Research checked 12 November 2026. Demo-only controls use temporary page state. No medical records collected, no backend, no trained prediction model.</Closing>
 </FileCard>
}
