import React from 'react';
import {regions} from './data';
export function Anatomy({counts,selected,onSelect,back,skeleton,motion,available}:any){
 const max=Math.max(1,...Object.values(counts).map(Number));
 const fill=(id:string)=>!available?'#e5e2df':!counts[id]?'#f0ece9':`hsl(${18-18*counts[id]/max} 72% ${88-44*counts[id]/max}%)`;
 const part=(id:string,paths:string[])=><g key={id} role="button" tabIndex={0} aria-label={`Select ${regions.find(r=>r.id===id)?.name}`} onClick={()=>onSelect(id)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onSelect(id)}}} className={`bodypart ${selected===id?'chosen':''}`} fill={fill(id)} stroke={selected===id?'#251f21':'#a9a19b'} strokeWidth={selected===id?2.4:0.85}>{paths.map((d,i)=><path key={i} d={d}/>)}<title>{regions.find(r=>r.id===id)?.name}: {available?(counts[id]||0)+' episodes':'no mapped data'}</title></g>;
 return <svg viewBox="0 0 340 600" className={`anatomy ${motion?'moving':''}`} aria-label={`${back?'Posterior':'Anterior'} illustrative anatomy. Select a body region.`}>
 <defs><radialGradient id="aura"><stop stopColor="#e3ebe5"/><stop offset="1" stopColor="#fff" stopOpacity="0"/></radialGradient><pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse"><path d="M30 0H0V30" fill="none" stroke="#eeedeb" strokeWidth=".7"/></pattern></defs>
 <rect width="340" height="600" fill="url(#grid)"/><ellipse cx="170" cy="288" rx="160" ry="270" fill="url(#aura)"/><ellipse cx="170" cy="570" rx="80" ry="9" fill="#e7e5e1"/>
 <g className="figure">
 {part('head',['M151 32Q170 20 189 32Q202 54 190 76L183 87V105H157V87Q138 67 145 46Z'])}
 <g fill="#e6ded7" stroke="#a9a19b" strokeWidth=".8"><path d="M157 100L125 112 120 151 131 201 142 247 150 273H190L198 247 209 201 220 151 215 112 183 100Z"/>
 {back?<><path d="M170 105V259" stroke="#faf8f5" strokeWidth="5"/><path d="M130 126Q157 150 166 176L143 165ZM210 126Q183 150 174 176L197 165Z" fill="#d3bcb0"/></>:<><path d="M167 117Q139 105 126 128L130 153Q148 163 167 151ZM173 117Q201 105 214 128L210 153Q192 163 173 151Z" fill="#d3bcb0"/>{[164,185,206].map(y=><g key={y}><rect x="151" y={y} width="16" height="16" rx="4"/><rect x="173" y={y} width="16" height="16" rx="4"/></g>)}</>}
 </g>
 {part('shoulder',['M127 111Q108 107 101 127L102 154 121 153 129 132Z','M213 111Q232 107 239 127L238 154 219 153 211 132Z'])}
 {part('upperarm',['M103 156L121 156 111 209 95 207Z','M237 156L219 156 229 209 245 207Z'])}
 {part('elbow',['M95 208Q99 202 111 210L110 225 91 224Z','M245 208Q241 202 229 210L230 225 249 224Z'])}
 <g fill="#d7cec7" stroke="#a9a19b" strokeWidth=".8"><path d="M92 225L110 226 96 289 82 286Z"/><path d="M248 225L230 226 244 289 258 286Z"/></g>
 {part('hand',['M81 285L96 291 95 317 88 332 76 328 74 310 72 300Z','M259 285L244 291 245 317 252 332 264 328 266 310 268 300Z'])}
 {part('back',[back?'M142 194Q153 188 166 200V251L146 259 138 238Z':'M139 220L150 232 167 244V263L149 258Z',back?'M198 194Q187 188 174 200V251L194 259 202 238Z':'M201 220L190 232 173 244V263L191 258Z'])}
 {part('hip',['M147 260L167 265V296L152 309 138 291Z','M193 260L173 265V296L188 309 202 291Z'])}
 {part('thigh',['M137 293L152 308 166 299 161 367 154 391 137 389 128 353Z','M203 293L188 308 174 299 179 367 186 391 203 389 212 353Z'])}
 {part('knee',['M137 391Q144 385 155 392L157 414 137 417 133 404Z','M203 391Q196 385 185 392L183 414 203 417 207 404Z'])}
 {part('lowerleg',['M137 420L157 418 151 451 146 490 132 493 128 453Z','M203 420L183 418 189 451 194 490 208 493 212 453Z'])}
 {part('ankle',['M132 494L146 492 145 526 129 529Z','M208 494L194 492 195 526 211 529Z'])}
 {part('foot',['M128 529L145 529 147 546 142 561 116 561Q111 551 119 542Z','M212 529L195 529 193 546 198 561 224 561Q229 551 221 542Z'])}
 <g fill="none" stroke="#fff" strokeOpacity=".45" strokeWidth="1" pointerEvents="none">{[0,1].map(i=><g key={i} transform={i?'translate(340 0) scale(-1 1)':''}><path d="M146 302L141 371M152 312L148 372M139 430L137 483M109 161L101 202M119 118L109 140"/></g>)}</g>
 {skeleton&&<g fill="none" stroke="#fffaf2" strokeWidth="7" strokeLinecap="round" opacity=".87" pointerEvents="none"><ellipse cx="170" cy="56" rx="17" ry="23"/><path d="M170 88V260M170 116L112 131 103 214 89 285M170 116L228 131 237 214 251 285M146 283L148 400 138 521M194 283L192 400 202 521"/>{[134,147,160,173,186].map(y=><path key={y} d={`M148 ${y}Q170 ${y+13} 192 ${y}`}/>)}<ellipse cx="170" cy="272" rx="23" ry="15"/></g>}
 </g><text x="14" y="22" className="svg-note">{back?'POSTERIOR':'ANTERIOR'} / REGIONAL VIEW</text><text x="170" y="592" textAnchor="middle" className="svg-note">ILLUSTRATION · NOT A MEDICAL 3D MODEL</text>
 </svg>
}
