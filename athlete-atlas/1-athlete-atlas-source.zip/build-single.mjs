// Builds dist/index.html as one self-contained file (CSS + JS inlined).
// Usage: node build-single.mjs [mesh-file-name]   (default muscles.bin; the live GitHub Pages copy uses 8-muscles.bin)
import {readFile,writeFile} from 'node:fs/promises';
const mesh=process.argv[2]||'muscles.bin';
const css=await readFile('dist/app.css','utf8');
let js=await readFile('dist/app.js','utf8');
js=js.replaceAll('./muscles.bin','./'+mesh).replace(/<\/script/gi,'<\\/script');
const html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Explore athlete injury evidence and original interactive anatomy. Research prototype, not medical advice."><title>Athlete Atlas</title><style>'+css+'</style></head><body><div id="root"></div><script type="module">'+js+'</script></body></html>';
await writeFile('dist/index-single.html',html);
console.log('dist/index-single.html',html.length,'bytes, mesh',mesh);
