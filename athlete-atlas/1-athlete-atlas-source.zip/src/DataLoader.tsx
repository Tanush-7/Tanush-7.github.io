import React, { useRef, useState } from 'react';
import { Group, TextLink } from './ui';
import { parseDataset, type KaggleSummary, type LoadedData } from './parseData';
import { kaggleBuiltIn, kaggleUrl } from './kaggleData';

const TEMPLATE = [
  'sport,region,count',
  'Football,Knee,14',
  'Football,Thigh / hamstrings,9',
  'Football,Ankle,7',
  'Running,Lower leg / Achilles,11',
  'Running,Knee,8',
  'Basketball,Ankle,10',
  'Basketball,Knee,6'
].join('\n');

function SummaryTable({ s }: { s: KaggleSummary }) {
  return <div>
    <p className="fine">{s.sessions.toLocaleString('en-IN')} monitored sessions · {s.athletes} athletes · Healthy {s.healthy.toLocaleString('en-IN')} · Low risk {s.low.toLocaleString('en-IN')} · Injured {s.injured.toLocaleString('en-IN')} ({(100 * s.injured / s.sessions).toFixed(1)}% of sessions)</p>
    <table className="load-table"><thead><tr><th>Sport (as recorded)</th><th>Sessions</th><th>Athletes</th><th>Injured sessions</th><th>Low risk</th></tr></thead>
      <tbody>{s.perSport.map(r => <tr key={r.sport}><td>{r.sport}</td><td>{r.sessions.toLocaleString('en-IN')}</td><td>{r.athletes}</td><td>{r.injured.toLocaleString('en-IN')} ({r.injuredPct}%)</td><td>{r.low.toLocaleString('en-IN')}</td></tr>)}</tbody></table>
    <p className="fine">This dataset records sessions and outcomes, not body regions, so it cannot colour the anatomy map. It is shown as per-sport session rates only. Soccer is Football in the atlas sport list; Track is Running.</p>
  </div>;
}

export function DataLoader({ onLoad }: { onLoad: (d: LoadedData) => void }) {
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [uploaded, setUploaded] = useState<KaggleSummary | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function handleFile(file: File) {
    setError(''); setStatus(''); setUploaded(null);
    let text = '';
    try { text = await file.text(); } catch { setError('That file could not be read.'); return; }
    const result = parseDataset(text, file.name);
    if (result.kind === 'error') { setError(result.message); return; }
    if (result.kind === 'kaggle') {
      setUploaded(result.summary);
      setStatus(`${file.name} loaded: it matches the Kaggle session format, so it is summarised below instead of colouring the map.`);
      return;
    }
    const d = result.data;
    onLoad(d);
    setStatus(`${file.name} loaded: ${d.totalEvents.toLocaleString('en-IN')} injury events mapped to the 12 regions${d.hasSport ? ` across ${d.sportsFound.length ? d.sportsFound.join(', ') : 'no atlas sport'}` : ' (no sport column, so it applies to every sport selection)'}.${d.unmatchedRegions ? ` ${d.unmatchedRegions} row${d.unmatchedRegions > 1 ? 's' : ''} had a region that could not be mapped and ${d.unmatchedRegions > 1 ? 'were' : 'was'} excluded.` : ''}${d.otherSportRows ? ` ${d.otherSportRows} row${d.otherSportRows > 1 ? 's were' : ' was'} for sports outside the ten atlas activities and count toward every sport selection.` : ''} Open your map above and the data view is set to Loaded data. The file was read on this device only; nothing was uploaded.`);
  }

  function downloadTemplate() {
    const url = URL.createObjectURL(new Blob([TEMPLATE], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url; a.download = 'athlete-atlas-template.csv'; a.click();
    URL.revokeObjectURL(url);
  }

  return <Group label="Load data" heading="Use your own dataset">
    <p>Load a CSV or JSON file with a region column (<b>region</b>, <b>body_part</b> or <b>location</b>), an optional <b>sport</b> column and an optional <b>count</b> column. With no count column, each row counts as one injury event. Region names are matched to the 12 atlas regions (for example Hamstring counts under Thigh, Achilles under Lower leg). The counts then drive the anatomy map as a separate Loaded data view, kept apart from the published and fictional layers. Files are parsed in this page on your device; nothing is uploaded, saved or sent.</p>
    <div className="load-actions">
      <label className="file-button load-pick">Choose CSV or JSON file<input ref={fileRef} type="file" accept=".csv,.json,text/csv,application/json" hidden onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); e.target.value = ''; }} /></label>
      <button type="button" className="file-button" onClick={downloadTemplate}>Download a template CSV</button>
    </div>
    {status && <p className="load-status" role="status">{status}</p>}
    {error && <p className="load-status load-error" role="alert">{error}</p>}
    {uploaded && <SummaryTable s={uploaded} />}
    <details className="source-row">
      <summary>Included dataset: Multimodal Sports Injury Dataset (Kaggle, 2025)</summary>
      <SummaryTable s={kaggleBuiltIn} />
      <p className="fine">Counted from the CSV on 12 November 2026. The dataset README rounds the class totals slightly differently (9,869 healthy, 2,313 injured); the CSV itself counts 9,868 and 2,314. License CC BY-NC-SA 4.0 (non-commercial, attribution, share-alike). To load the full file yourself, download it from Kaggle and choose it above; it will be summarised the same way.</p>
      <TextLink href={kaggleUrl}>Open the dataset on Kaggle</TextLink>
    </details>
  </Group>;
}
