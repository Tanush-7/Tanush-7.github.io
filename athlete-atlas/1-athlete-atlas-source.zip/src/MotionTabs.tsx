import React,{useLayoutEffect,useRef,useState} from 'react';
// Pill tabs with a sliding active indicator (beui.dev motion/tabs pattern,
// reimplemented without dependencies). Keyboard: tab/arrow friendly buttons.
export function MotionTabs({label,tabs,value,onChange,children}:{label:string;tabs:string[];value:string;onChange:(t:string)=>void;children:React.ReactNode}){
 const listRef=useRef<HTMLDivElement>(null);const [ind,setInd]=useState({x:0,w:0,ready:false});
 useLayoutEffect(()=>{
  const el=listRef.current;if(!el)return;
  const btn=el.querySelector(`[data-tab="${CSS.escape(value)}"]`) as HTMLElement|null;
  if(btn)setInd({x:btn.offsetLeft,w:btn.offsetWidth,ready:true});
 },[value]);
 return <div className="mtabs">
  <span className="file-control-label">{label}</span>
  <div className="mtabs-list" role="tablist" ref={listRef}>
   <span className="mtabs-ind" style={{transform:`translateX(${ind.x}px)`,width:ind.w,opacity:ind.ready?1:0}} aria-hidden="true"/>
   {tabs.map(t=><button key={t} type="button" role="tab" data-tab={t} aria-selected={value===t} className="mtabs-tab" onClick={()=>onChange(t)}>{t}</button>)}
  </div>
  <div role="tabpanel" className="tab-content">{children}</div>
 </div>;
}
