import React,{useEffect,useRef} from 'react';
// Original geometric logomark animation for Athlete Atlas: a rounded-square
// mark dissolves into white particles, morphs through rotating 3D forms and
// reassembles, on black. Canvas particles, no external assets or libraries.
type Pt={hx:number;hy:number;sx:number;sy:number;ox:number;oy:number;oz:number;bx:number;by:number;bz:number;d:number;r:number};
const T=9000,SEG=[2200,3400,4700,6300,7900]; // assembled, dissolve, sphere, cube, reassemble ends
const clamp=(v:number)=>v<0?0:v>1?1:v;
const ease=(p:number)=>p*p*(3-2*p);
function roundRect(c:CanvasRenderingContext2D,x:number,y:number,w:number,h:number,r:number){
 c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();
}
function markCanvas(S:number){ // offscreen render of the flat geometric mark
 const m=document.createElement('canvas');m.width=m.height=S;const c=m.getContext('2d')!;
 c.strokeStyle='#fff';c.lineWidth=26;c.lineCap='round';c.lineJoin='round';
 roundRect(c,S/2-160,S/2-160,320,320,74);c.stroke();
 c.beginPath();c.moveTo(S/2-86,S/2+96);c.lineTo(S/2,S/2-96);c.lineTo(S/2+86,S/2+96);c.stroke(); // A
 c.beginPath();c.moveTo(S/2-46,S/2+34);c.lineTo(S/2+46,S/2+34);c.stroke(); // crossbar
 return m;
}
export function LogoMark(){
 const ref=useRef<HTMLCanvasElement|null>(null);
 useEffect(()=>{
  const canvas=ref.current;if(!canvas)return;
  const ctx=canvas.getContext('2d');if(!ctx)return;
  const S=560;canvas.width=S;canvas.height=S;
  const mark=markCanvas(S);
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduced){ctx.drawImage(mark,0,0);return}
  const data=mark.getContext('2d')!.getImageData(0,0,S,S).data;
  const pts:Pt[]=[];const N=760;let seed=42;
  const rnd=()=>(seed=(seed*1103515245+12345)&0x7fffffff)/0x7fffffff;
  const cands:number[]=[];
  for(let y=0;y<S;y+=5)for(let x=0;x<S;x+=5)if(data[(y*S+x)*4+3]>120)cands.push(x,y);
  const total=cands.length/2;
  for(let i=0;i<N;i++){
   const j=(i*2+((rnd()*total)|0)*2)%(total*2);
   const hx=cands[j]+(rnd()-0.5)*4,hy=cands[j+1]+(rnd()-0.5)*4;
   const a=rnd()*Math.PI*2,dist=90+rnd()*240;
   const th=Math.acos(1-2*(i+0.5)/N),ph=Math.PI*(1+Math.sqrt(5))*i; // fibonacci sphere
   const R=150;
   const face=(rnd()*6)|0,u=(rnd()-0.5)*250,v=(rnd()-0.5)*250,h=125; // cube faces
   const cube=[[u,v,h],[u,v,-h],[h,u,v],[-h,u,v],[u,h,v],[u,-h,v]][face];
   pts.push({hx,hy,sx:hx+Math.cos(a)*dist,sy:hy+Math.sin(a)*dist,
    ox:R*Math.sin(th)*Math.cos(ph)+S/2,oy:R*Math.cos(th)*0.98+S/2,oz:R*Math.sin(th)*Math.sin(ph),
    bx:cube[0]+S/2,by:cube[1]+S/2,bz:cube[2],d:rnd(),r:1.2+rnd()*1.5});
  }
  let raf=0;const t0=performance.now();
  const frame=(now:number)=>{
   const t=(now-t0)%T;
   ctx.clearRect(0,0,S,S);
   const rot=(t/1000)*1.1,cr=Math.cos(rot),sr=Math.sin(rot),tilt=0.42,ct=Math.cos(tilt),st=Math.sin(tilt);
   for(const p of pts){
    let x,y,alpha=1,scale=1;
    const local=(start:number,end:number)=>ease(clamp((t-start-p.d*420)/(end-start-420)));
    if(t<SEG[0]){x=p.hx;y=p.hy}
    else if(t<SEG[1]){const p1=local(SEG[0],SEG[1]);x=p.hx+(p.sx-p.hx)*p1;y=p.hy+(p.sy-p.hy)*p1}
    else if(t<SEG[2]){const p1=local(SEG[1],SEG[2]);x=p.sx+(p.ox-p.sx)*p1;y=p.sy+(p.oy-p.sy)*p1;alpha=0.55+0.45*p1}
    else if(t<SEG[3]){const p1=local(SEG[2],SEG[3]);
     const rx=(p.ox-S/2)*cr+p.oz*sr,rz=p.oz*cr-(p.ox-S/2)*sr,ry=p.oy-S/2;
     const tx=(p.bx-S/2)*cr+p.bz*sr,tz=p.bz*cr-(p.bx-S/2)*sr,ty=p.by-S/2;
     const gx=rx+(tx-rx)*p1,gy=ry+(ty-ry)*p1,gz=rz+(tz-rz)*p1;
     const py=gy*ct-gz*st,pz=gy*st+gz*ct;
     x=S/2+gx;y=S/2+py;scale=0.75+((pz+170)/340)*0.6;alpha=0.5+((pz+170)/340)*0.5}
    else if(t<SEG[4]){const p1=local(SEG[3],SEG[4]);
     const tx=(p.bx-S/2)*cr+p.bz*sr,tz=p.bz*cr-(p.bx-S/2)*sr,ty=p.by-S/2;
     const py=ty*ct-tz*st;
     x=S/2+tx+(p.hx-(S/2+tx))*p1;y=S/2+py+(p.hy-(S/2+py))*p1}
    else{x=p.hx;y=p.hy}
    ctx.globalAlpha=Math.max(0.15,Math.min(1,alpha));
    ctx.fillStyle='#fff';
    ctx.beginPath();ctx.arc(x,y,p.r*scale,0,6.2832);ctx.fill();
   }
   ctx.globalAlpha=1;
   raf=requestAnimationFrame(frame);
  };
  raf=requestAnimationFrame(frame);
  return ()=>cancelAnimationFrame(raf);
 },[]);
 return <canvas ref={ref} className="logomark-canvas" role="img" aria-label="Animated Athlete Atlas mark: a geometric symbol dissolving into particles and reassembling"/>;
}
