// Pure parsing for user-loaded datasets. No DOM, no network: files are read
// in the page and never leave the device.
export interface LoadedRow { sport: string | null; region: string; count: number }
export interface LoadedData {
  name: string;
  rows: LoadedRow[];
  totalEvents: number;
  unmatchedRegions: number;
  otherSportRows: number;
  sportsFound: string[];
  hasSport: boolean;
}
export interface KaggleSport { sport: string; sessions: number; athletes: number; injured: number; injuredPct: number; low: number }
export interface KaggleSummary { sessions: number; athletes: number; healthy: number; low: number; injured: number; perSport: KaggleSport[] }
export type ParseResult =
  | { kind: 'regions'; data: LoadedData }
  | { kind: 'kaggle'; name: string; summary: KaggleSummary }
  | { kind: 'error'; message: string };

const ATLAS_SPORTS = ['HYROX', 'Cricket', 'Badminton', 'Running', 'Football', 'Basketball', 'Tennis', 'Volleyball', 'Swimming', 'Cycling'];
const SPORT_ALIASES: Record<string, string> = {
  soccer: 'Football', football: 'Football', track: 'Running', 'track and field': 'Running',
  'track & field': 'Running', running: 'Running', hyrox: 'HYROX', cricket: 'Cricket',
  badminton: 'Badminton', basketball: 'Basketball', tennis: 'Tennis', volleyball: 'Volleyball',
  swimming: 'Swimming', cycling: 'Cycling'
};
export function mapSport(raw: string): string | null {
  const key = raw.trim().toLowerCase();
  if (!key) return null;
  if (SPORT_ALIASES[key]) return SPORT_ALIASES[key];
  const hit = ATLAS_SPORTS.find(s => s.toLowerCase() === key);
  return hit || null;
}

// Ordered: specific terms before generic ones.
const REGION_RULES: [string, string[]][] = [
  ['head', ['concussion', 'head', 'skull', 'face']],
  ['shoulder', ['shoulder', 'rotator', 'clavicle', 'collarbone', 'ac joint', 'acromioclavicular']],
  ['elbow', ['elbow']],
  ['hand', ['wrist', 'hand', 'finger', 'thumb', 'metacarpal']],
  ['upperarm', ['upper arm', 'biceps', 'triceps', 'humerus', 'arm']],
  ['thigh', ['hamstring', 'thigh', 'quad', 'femoral']],
  ['knee', ['acl', 'mcl', 'pcl', 'meniscus', 'knee', 'patella', 'ligament']],
  ['lowerleg', ['achilles', 'calf', 'shin', 'lower leg', 'gastrocnemius', 'soleus', 'tibia']],
  ['ankle', ['ankle']],
  ['foot', ['foot', 'toe', 'plantar', 'heel', 'metatars', 'arch']],
  ['hip', ['groin', 'hip', 'adductor', 'glute', 'iliopsoas']],
  ['back', ['back', 'lumbar', 'spine', 'spinal', 'pelvis', 'pelvic', 'sacroiliac', 'disc']]
];
const REGION_IDS = REGION_RULES.map(r => r[0]);
export function mapRegion(raw: string): string | null {
  const text = ' ' + raw.trim().toLowerCase().replace(/[_/-]+/g, ' ') + ' ';
  if (!text.trim()) return null;
  for (const id of REGION_IDS) if (text.includes(' ' + id + ' ') || raw.trim().toLowerCase() === id) return id;
  for (const [id, keys] of REGION_RULES) for (const k of keys) if (text.includes(k)) return id;
  return null;
}

export function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let row: string[] = [], cell = '', quoted = false;
  const src = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (quoted) {
      if (c === '"') { if (src[i + 1] === '"') { cell += '"'; i++; } else quoted = false; }
      else cell += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i++;
      row.push(cell); cell = '';
      if (row.some(v => v.trim() !== '')) rows.push(row);
      row = [];
    } else cell += c;
  }
  row.push(cell);
  if (row.some(v => v.trim() !== '')) rows.push(row);
  if (rows.length < 2) return [];
  const headers = rows[0].map(h => h.trim().toLowerCase());
  return rows.slice(1).map(r => Object.fromEntries(headers.map((h, i) => [h, (r[i] ?? '').trim()])));
}

const REGION_COLS = ['region', 'body_region', 'body_part', 'bodypart', 'body region', 'body part', 'location', 'injury_location', 'injury location', 'body_area', 'area', 'site'];
const SPORT_COLS = ['sport', 'sport_type', 'sport type', 'activity'];
const COUNT_COLS = ['count', 'episodes', 'injuries', 'injury_count', 'n', 'total', 'events', 'frequency'];
const pick = (cols: string[], wanted: string[]) => wanted.find(w => cols.includes(w));

function summariseKaggle(rows: Record<string, string>[], name: string): ParseResult {
  const athletes = new Set<string>();
  const per = new Map<string, { sessions: number; athletes: Set<string>; injured: number; low: number }>();
  let healthy = 0, low = 0, injured = 0, valid = 0;
  for (const r of rows) {
    const cls = parseInt(r['injury_occurred'], 10);
    if (![0, 1, 2].includes(cls)) continue;
    valid++;
    const sport = r['sport_type'] || 'Unspecified';
    if (r['athlete_id']) athletes.add(r['athlete_id']);
    if (!per.has(sport)) per.set(sport, { sessions: 0, athletes: new Set(), injured: 0, low: 0 });
    const d = per.get(sport)!;
    d.sessions++;
    if (r['athlete_id']) d.athletes.add(r['athlete_id']);
    if (cls === 2) { injured++; d.injured++; } else if (cls === 1) { low++; d.low++; } else healthy++;
  }
  if (!valid) return { kind: 'error', message: 'This looks like the Kaggle session format, but no rows had a valid injury_occurred value (0, 1 or 2).' };
  const perSport = [...per.entries()].map(([sport, d]) => ({ sport, sessions: d.sessions, athletes: d.athletes.size, injured: d.injured, injuredPct: Math.round(1000 * d.injured / d.sessions) / 10, low: d.low })).sort((a, b) => b.sessions - a.sessions);
  return { kind: 'kaggle', name, summary: { sessions: valid, athletes: athletes.size, healthy, low, injured, perSport } };
}

function aggregate(name: string, records: { sport?: string; region?: string; count?: string }[]): ParseResult {
  const rows: LoadedRow[] = [];
  const sportsFound = new Set<string>();
  let unmatchedRegions = 0, otherSportRows = 0, totalEvents = 0;
  let hasSport = false;
  for (const rec of records) {
    const regionRaw = (rec.region ?? '').toString();
    const region = mapRegion(regionRaw);
    const parsed = rec.count !== undefined && rec.count !== '' ? parseFloat(rec.count as string) : 1;
    const count = Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
    if (!region) { unmatchedRegions++; continue; }
    let sport: string | null = null;
    if (rec.sport !== undefined && (rec.sport as string).trim() !== '') {
      hasSport = true;
      sport = mapSport(rec.sport as string);
      if (sport) sportsFound.add(sport); else otherSportRows++;
    }
    rows.push({ sport, region, count });
    totalEvents += count;
  }
  if (!rows.length) return { kind: 'error', message: 'No rows could be mapped to the 12 atlas regions. Check the region/body_part column values (for example Knee, Hamstring, Ankle, Lower back).' };
  return { kind: 'regions', data: { name, rows, totalEvents, unmatchedRegions, otherSportRows, sportsFound: [...sportsFound], hasSport } };
}

export function parseDataset(text: string, name: string): ParseResult {
  const trimmed = text.trim();
  if (!trimmed) return { kind: 'error', message: 'That file is empty.' };
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    let json: any;
    try { json = JSON.parse(trimmed); } catch { return { kind: 'error', message: 'That JSON file could not be parsed.' }; }
    if (Array.isArray(json)) {
      if (!json.length) return { kind: 'error', message: 'That JSON array is empty.' };
      const first = json[0] || {};
      const keys = Object.keys(first).map(k => k.toLowerCase());
      const regionCol = pick(keys, REGION_COLS), sportCol = pick(keys, SPORT_COLS), countCol = pick(keys, COUNT_COLS);
      if (!regionCol) return { kind: 'error', message: 'No region column found. Use a region, body_part or location field in each record.' };
      const keyOf = (obj: any, col: string) => Object.keys(obj).find(k => k.toLowerCase() === col);
      return aggregate(name, json.map((obj: any) => ({ region: obj[keyOf(obj, regionCol)!], sport: sportCol ? obj[keyOf(obj, sportCol)!] : undefined, count: countCol ? obj[keyOf(obj, countCol)!] : undefined })));
    }
    if (json && typeof json === 'object') {
      const records = Object.entries(json).map(([region, count]) => ({ region, count: String(count as any) }));
      return aggregate(name, records);
    }
    return { kind: 'error', message: 'Unsupported JSON shape. Use an array of records or a {region: count} object.' };
  }
  const rows = parseCsv(trimmed);
  if (!rows.length) return { kind: 'error', message: 'No data rows found. A header row plus at least one data row is needed.' };
  const cols = Object.keys(rows[0]);
  const regionCol = pick(cols, REGION_COLS);
  if (!regionCol && cols.includes('injury_occurred') && cols.includes('sport_type')) return summariseKaggle(rows, name);
  if (!regionCol) return { kind: 'error', message: 'No region column found. Add a column named region, body_part or location. Session-level files like the Kaggle dataset (sport_type + injury_occurred, no region) are summarised instead, and this file does not match that format either.' };
  const sportCol = pick(cols, SPORT_COLS), countCol = pick(cols, COUNT_COLS);
  return aggregate(name, rows.map(r => ({ region: r[regionCol], sport: sportCol ? r[sportCol] : undefined, count: countCol ? r[countCol] : undefined })));
}
