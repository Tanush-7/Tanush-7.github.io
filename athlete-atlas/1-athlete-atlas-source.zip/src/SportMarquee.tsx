import React from 'react';
import {SportIcon} from './icons';
// Infinite-loop marquee of sport buttons (pattern adapted from the MIT-style
// beui.dev motion/marquee recipe: duplicated tracks, gap-aware loop, edge fade,
// pause on hover). Buttons keep the app's existing sport-selection behaviour.
function Track({sports,value,onChange,dup}:{sports:string[];value:string;onChange:(s:string)=>void;dup:boolean}){
 return <div className="marquee-track" aria-hidden={dup||undefined}>
  {sports.map(s=><button key={s} type="button" className="sport-chip" tabIndex={dup?-1:undefined}
   aria-pressed={!dup&&value===s||undefined} onClick={()=>onChange(s)}>
   <SportIcon sport={s}/><span>{s}</span></button>)}
 </div>;
}
export function SportMarquee({label,sports,value,onChange}:{label:string;sports:string[];value:string;onChange:(s:string)=>void}){
 return <div className="file-control" role="group" aria-label={label}>
  <span className="file-control-label">{label}</span>
  <div className="marquee">
   <Track sports={sports} value={value} onChange={onChange} dup={false}/>
   <Track sports={sports} value={value} onChange={onChange} dup={true}/>
  </div>
  <p className="marquee-hint">A scrolling row - hover to pause, or Tab through the buttons. Selecting a sport updates the explorer below.</p>
 </div>;
}
