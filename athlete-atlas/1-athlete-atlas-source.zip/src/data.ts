export const sports: Record<string,string[]> = {
 'HYROX':['Singles','Doubles','Relay'], 'Cricket':['Fast bowler','Spin bowler','Batter','Wicketkeeper'], 'Badminton':['Singles','Doubles'], 'Running':['Road','Trail','Track'], 'Football':['Goalkeeper','Defender','Midfielder','Forward'], 'Basketball':['Guard','Forward','Centre'], 'Tennis':['Singles','Doubles'], 'Volleyball':['Setter','Outside hitter','Middle blocker','Libero'], 'Swimming':['Freestyle','Backstroke','Breaststroke','Butterfly'], 'Cycling':['Road','Track','Mountain bike']
};
export const sources = [
 {id:'hyrox',title:'HYROX: 12-week prospective cohort (2026)',url:'https://www.frontiersin.org/journals/sports-and-active-living/articles/10.3389/fspor.2026.1937574/full',note:'89 athletes, 63 injury episodes, 4,376 exposure hours. Table 3 provides region counts. All injuries in HYROX athletes, not only injuries attributed to HYROX. One small self-selected cohort; mean weekly response 62%.'},
 {id:'hsi',title:'Hamstring risk factors: systematic review (2020)',url:'https://bjsm.bmj.com/content/54/18/1081',note:'Previous hamstring injury was associated with subsequent hamstring injury across the included sports. Role findings are not a personal prediction.'},
 {id:'ankle',title:'Previous ankle sprain: systematic review (2021)',url:'https://pubmed.ncbi.nlm.nih.gov/34375983/',note:'19 prospective studies. Previous lateral ankle sprain was associated with subsequent sprain; sex-specific evidence was limited.'},
 {id:'acl',title:'ACL incidence by sex and sport (2019)',url:'https://pmc.ncbi.nlm.nih.gov/articles/PMC6602364/',note:'Group-level sex differences depend on sport category. Do not apply a universal sex multiplier to an individual.'},
 {id:'cricket',title:'Fast-bowler lumbar injury review (2023)',url:'https://link.springer.com/article/10.1186/s13102-023-00732-1',note:'25 studies; none rated low risk of bias. Many findings conflicted. Not a validated fast-bowler risk score.'},
 {id:'run',title:'Running injury risk factors (2015)',url:'https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0114937',note:'Previous injury was associated with running injuries; sex-specific findings need caution.'},
 {id:'ml',title:'Can sports injury models be trusted? (2022)',url:'https://pubmed.ncbi.nlm.nih.gov/35689749/',note:'Methodological review of sports injury prediction models. Associations alone are not a validated prediction service.'},
 {id:'ioc',title:'IOC injury surveillance consensus (2020)',url:'https://bjsm.bmj.com/content/54/7/372',note:'Use defined injury outcomes, exposure, severity and population characteristics before comparing groups.'},
 {id:'knee-ex',title:'AAOS knee conditioning',url:'https://www.orthoinfo.org/bodypart/kneelower-leg/knee-conditioning-program/',note:'General conditioning under doctor/physiotherapist supervision. Stop if exercise causes pain.'},
 {id:'ankle-ex',title:'AAOS foot and ankle conditioning',url:'https://www.orthoinfo.org/bodypart/foot-ankle/foot-and-ankle-conditioning-program/',note:'General conditioning under clinical supervision, including calf raises and single-leg balance.'},
 {id:'back-ex',title:'AAOS spine conditioning',url:'https://www.orthoinfo.org/recovery/spine-conditioning-program/',note:'General conditioning under clinical supervision, including bird dog and hip bridge.'},
 {id:'shoulder-ex',title:'AAOS shoulder conditioning',url:'https://orthoinfo.aaos.org/en/recovery/rotator-cuff-and-shoulder-conditioning-program/',note:'General conditioning under clinical supervision, including standing row and scapula setting.'}
];
export const exfreq: Record<string,string> = {
 'Standing row':'3 sets of 8 · 3 days/week','Scapula setting':'10 reps · 3 days/week',
 'Elbow flexion':'3 sets of 8 · 3 days/week','Elbow extension':'3 sets of 8 · 3 days/week',
 'Bird dog':'5 reps · Daily','Hip bridge':'5 reps · Daily',
 'Hip abduction':'3 sets of 20 · 4-5 days/week','Hip adduction':'3 sets of 20 · 4-5 days/week',
 'Hamstring curls':'3 sets of 10 · 4-5 days/week','Straight-leg raises':'3 sets of 10 · 4-5 days/week','Half squats':'3 sets of 10 · 4-5 days/week',
 'Calf raises':'2 sets of 10 · 6-7 days/week','Single-leg balance':'3-5 reps · 6-7 days/week','Ankle range of motion':'2 sets · Daily','Towel curls':'20 reps · Daily'
};
export const regions = [
 {id:'head',name:'Head',n:2,examples:'Injury types require a clinical assessment; a regional count is not a diagnosis.',ex:[],source:'',cue:''},
 {id:'shoulder',name:'Shoulder',n:1,examples:'Shoulder pain can involve several tissues. The diagram does not identify a rotator-cuff injury.',ex:['Standing row','Scapula setting'],source:'shoulder-ex',cue:'For a standing row, keep the elbow close and draw it back slowly. A clinician should choose resistance and range.'},
 {id:'upperarm',name:'Upper arm',n:2,examples:'Regional injury reports do not identify a specific muscle or tendon injury.',ex:['Elbow flexion'],source:'shoulder-ex',cue:'The AAOS conditioning guide includes controlled elbow flexion. Choose loading with a clinician rather than treating pain from this map.'},
 {id:'elbow',name:'Elbow',n:4,examples:'A regional count cannot distinguish tendon pain, joint injury or other causes.',ex:['Elbow flexion','Elbow extension'],source:'shoulder-ex',cue:'Controlled elbow movement is a conditioning example, not a treatment for an undiagnosed elbow injury.'},
 {id:'hand',name:'Hand / fingers',n:2,examples:'Contact, tendon and joint injuries need different care. Do not infer a diagnosis from the heat map.',ex:[],source:'',cue:''},
 {id:'back',name:'Pelvis / lower back',n:6,examples:'Back symptoms and lumbar bone stress injury are not interchangeable. The original study groups pelvis and lower back together.',ex:['Bird dog','Hip bridge'],source:'back-ex',cue:'For bird dog, start on hands and knees and extend an opposite arm and leg while keeping the trunk steady, only if cleared and pain-free.'},
 {id:'hip',name:'Hip / groin',n:7,examples:'The region includes different muscle, tendon and joint problems; no diagnosis is assigned.',ex:['Hip abduction','Hip adduction'],source:'knee-ex',cue:'AAOS lists side-lying hip raises as conditioning. Keep movement controlled; ask a clinician which direction and load fit your situation.'},
 {id:'thigh',name:'Thigh / hamstrings',n:3,examples:'Hamstring strain is one possible thigh injury, but the study reports all thigh injuries together.',ex:['Hamstring curls'],source:'knee-ex',cue:'Hold a chair for balance and bend the knee to lift the heel, only within a pain-free range. This is not acute hamstring-strain rehabilitation.'},
 {id:'knee',name:'Knee',n:14,examples:'Knee reports may include different conditions. A red knee does not mean an ACL tear or predict one.',ex:['Straight-leg raises','Half squats'],source:'knee-ex',cue:'For a straight-leg raise, tighten the thigh with the working leg straight and lift slowly. A clinician should decide whether this is suitable.'},
 {id:'lowerleg',name:'Lower leg / Achilles',n:5,examples:'The cohort combines lower leg and Achilles. This map cannot distinguish tendon pain from bone stress injury.',ex:['Calf raises'],source:'ankle-ex',cue:'Use a stable support and rise onto the toes slowly if cleared and pain-free. Do not use this to self-treat suspected bone stress or Achilles rupture.'},
 {id:'ankle',name:'Ankle',n:3,examples:'Previous lateral ankle sprain is associated with subsequent sprain in prospective research.',ex:['Single-leg balance','Ankle range of motion'],source:'ankle-ex',cue:'For balance practice, stand beside stable support. A clinician should choose the difficulty, especially after a recent sprain.'},
 {id:'foot',name:'Foot',n:6,examples:'Foot pain has several possible causes. The map does not identify a stress fracture or clear you to run.',ex:['Towel curls'],source:'ankle-ex',cue:'AAOS includes drawing a towel toward you with the toes. Use only as suitable pain-free conditioning, not treatment for undiagnosed foot pain.'}
];
export function evidence(sport:string,region:string,history:string){
 const out:{text:string,source:string}[]=[];
 if(sport==='HYROX')out.push({text:'A 2026 HYROX cohort provides a real regional map here. Knee injuries were most frequent. Previous injury was an exploratory marker for cumulative severity, with an imprecise estimate compatible with no association. This is not a validated prediction model.',source:'hyrox'});
 if(sport==='Cricket' && region==='back')out.push({text:'Fast-bowler lumbar research reports a substantial problem but conflicting risk-factor results. The review had no low-risk-of-bias studies. Do not generalize fast-bowler findings to batters or wicketkeepers.',source:'cricket'});
 if(sport==='Running')out.push({text:'A running review found previous injury associated with later running injury. It did not establish a personalized probability for this region or this event type.',source:'run'});
 if(history==='Hamstring strain')out.push({text:'Previous hamstring injury is associated with later hamstring injury in a multi-sport review. The association does not mean every thigh symptom is a hamstring strain, and it is not calibrated to this selected sport, gender or role.',source:'hsi'});
 if(history==='Ankle sprain')out.push({text:'Previous lateral ankle sprain is associated with subsequent sprain. Sex-specific evidence is limited; no multiplier is applied to this scenario.',source:'ankle'});
 if(region==='knee' && ['Football','Basketball','Volleyball'].includes(sport))out.push({text:'ACL incidence differs by sex and sport classification in pooled studies. This is group-level incidence, not a risk calculation from gender identity.',source:'acl'});
 if(!out.length)out.push({text:'No directly matched sport × region × gender × role evidence has been curated for this selection yet. Anatomy and conditioning remain available; no risk estimate is calculated.',source:'ioc'});
 return out;
}
// Fixture data only. This deterministic generator is deliberately NOT an epidemiology model.
export const demo = Object.entries(sports).flatMap(([sport,roles],si)=>roles.flatMap((role,ri)=>['Women','Men','Nonbinary','Not specified'].flatMap((gender,gi)=>Array.from({length:8},(_,i)=>({sport,role,gender,region:regions[(i*i+si*3+ri+gi*2)%regions.length].id})))));
