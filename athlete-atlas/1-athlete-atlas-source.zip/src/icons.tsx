import React from 'react';
// Original stroke icons authored for Athlete Atlas. viewBox 24, stroke currentColor.
const P={fill:'none',stroke:'currentColor',strokeWidth:1.7,strokeLinecap:'round' as const,strokeLinejoin:'round' as const};
export function SportIcon({sport}:{sport:string}){
 switch(sport){
  case 'HYROX':return <svg viewBox="0 0 24 24" {...P}><path d="M9 7a3 3 0 0 1 6 0"/><path d="M6.5 7h11v2.2a5.5 5.5 0 1 1-11 0z"/><path d="M12 12v3"/></svg>;
  case 'Cricket':return <svg viewBox="0 0 24 24" {...P}><path d="M14.5 3.5l6 6-8.2 8.2a2.1 2.1 0 0 1-3 0l-3-3a2.1 2.1 0 0 1 0-3z"/><path d="M14.5 3.5l2-2 6 6-2 2"/><circle cx="6" cy="18" r="2.2"/></svg>;
  case 'Badminton':return <svg viewBox="0 0 24 24" {...P}><path d="M12 13.5L6 3m6 10.5L18 3m-6 10.5V4"/><path d="M6 3c2 3.5 10 3.5 12 0"/><path d="M9.6 14.9a2.9 2.9 0 1 0 4.8 0l-2.4-1.4z"/></svg>;
  case 'Running':return <svg viewBox="0 0 24 24" {...P}><circle cx="15.5" cy="4.5" r="1.9"/><path d="M13.5 8.5l-3 1-2 3.5"/><path d="M13.5 8.5l2.5 2 3.5.5"/><path d="M13.5 8.5l-1 4 3 3 1 4.5"/><path d="M12.5 12.5l-3.5 2-1.5 5"/><path d="M6.5 10l2-.5"/></svg>;
  case 'Football':return <svg viewBox="0 0 24 24" {...P}><circle cx="12" cy="12" r="8.5"/><path d="M12 8l3.4 2.5-1.3 4h-4.2l-1.3-4z"/><path d="M12 3.5V8m7.6 5.5l-4.2-1.4M15 20.3l-1.9-3.8m-4.1 3.8l1.9-3.8M4.4 13.5l4.2-1.4"/></svg>;
  case 'Basketball':return <svg viewBox="0 0 24 24" {...P}><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5v17"/><path d="M6 5.2c3 3.4 3 10.2 0 13.6M18 5.2c-3 3.4-3 10.2 0 13.6"/></svg>;
  case 'Tennis':return <svg viewBox="0 0 24 24" {...P}><ellipse cx="14.5" cy="8.5" rx="5.5" ry="6.5" transform="rotate(30 14.5 8.5)"/><path d="M10.5 13.5L4 20"/><path d="M11 6.5c2 1.5 4.5 2 7 1.5M10 10c2.5 1.5 5.5 1.8 8.5 1"/></svg>;
  case 'Volleyball':return <svg viewBox="0 0 24 24" {...P}><circle cx="12" cy="12" r="8.5"/><path d="M12 3.5c3 2 4.5 5 4.5 8.5M3.6 9.5c3.5.5 6.5 2.5 8.4 6M14 20.3c-1-3.5-.5-7 1.5-10"/></svg>;
  case 'Swimming':return <svg viewBox="0 0 24 24" {...P}><circle cx="16.5" cy="6" r="2"/><path d="M3 12.5l5.5-2 4 2 4.5-1 4 1.5"/><path d="M2.5 17.5c2-1.3 4-1.3 6 0s4 1.3 6 0 4-1.3 6 0"/><path d="M13 10.5l-4-3.5"/></svg>;
  case 'Cycling':return <svg viewBox="0 0 24 24" {...P}><circle cx="6" cy="16.5" r="3.5"/><circle cx="18" cy="16.5" r="3.5"/><path d="M6 16.5L9.5 9h5l3.5 7.5"/><path d="M9.5 9L8 6h2.5M14.5 9H13l-1.5 7.5"/></svg>;
  default:return <svg viewBox="0 0 24 24" {...P}><circle cx="12" cy="12" r="8.5"/></svg>;
 }
}
