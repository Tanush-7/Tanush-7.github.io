import type { KaggleSummary } from './parseData';
// Counted directly from multimodal_sports_injury_dataset.csv on 12 Nov 2026.
// (The dataset README rounds these to 9,869 healthy / 2,313 injured; the CSV
// itself counts 9,868 / 2,314.) License: CC BY-NC-SA 4.0, non-commercial.
export const kaggleBuiltIn: KaggleSummary = {
  sessions: 15420,
  athletes: 156,
  healthy: 9868,
  low: 3238,
  injured: 2314,
  perSport: [
    { sport: 'Soccer', sessions: 4837, athletes: 49, injured: 742, injuredPct: 15.3, low: 1037 },
    { sport: 'Track', sessions: 4147, athletes: 42, injured: 642, injuredPct: 15.5, low: 837 },
    { sport: 'Basketball', sessions: 4059, athletes: 41, injured: 581, injuredPct: 14.3, low: 876 },
    { sport: 'Other', sessions: 2377, athletes: 24, injured: 349, injuredPct: 14.7, low: 488 }
  ]
};
export const kaggleUrl = 'https://www.kaggle.com/datasets/anjalibhegam/multimodal-sports-injury-dataset';
