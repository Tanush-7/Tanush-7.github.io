import React,{useEffect,useRef,useState} from 'react';
import {regions} from './data';
// Muscular + skeletal anatomy meshes: BodyParts3D (c) The Database Center for
// Life Science, licensed under CC Attribution 4.0 International
// (https://creativecommons.org/licenses/by/4.0/). Citation: Mitsuhashi N et
// al., Nucleic Acids Res. 2009;37(Database issue):D782-6 (PMID 18835852).
// Meshes merged and quantized into muscles.bin; joint markers are procedural.
type MPart={name:string;region:string;bone:number;nv:number;ni:number;vo:number;io:number};
type JPart={id:string,p:number[],s:number[],r?:number};
const joints:JPart[]=[{id:'head',p:[0,2.45,0],s:[.27,.36,.25]},{id:'head',p:[0,2.06,0],s:[.14,.18,.14]}];
for(const side of [-1,1]){
 const add=(id:string,p:number[],s:number[],r=0)=>joints.push({id,p:[p[0]*side,p[1],p[2]],s,r:r*side});
 add('elbow',[.79,.96,0],[.14,.13,.15]);add('hand',[.98,.16,.02],[.13,.24,.09],.1);
 add('knee',[.3,-.48,.05],[.18,.17,.17]);add('ankle',[.3,-1.46,0],[.11,.18,.11]);add('foot',[.3,-1.69,.14],[.15,.12,.29]);
}
const VS=`attribute vec3 a;attribute vec3 n;uniform vec3 p;uniform vec3 s;uniform float rot;uniform float yaw;uniform float pitch;uniform float aspect;uniform float zoom;uniform float sc;varying vec3 normal;void main(){mat3 rz=mat3(cos(rot),sin(rot),0.,-sin(rot),cos(rot),0.,0.,0.,1.);mat3 ry=mat3(cos(yaw),0.,-sin(yaw),0.,1.,0.,sin(yaw),0.,cos(yaw));mat3 rx=mat3(1.,0.,0.,0.,cos(pitch),sin(pitch),0.,-sin(pitch),cos(pitch));mat3 view=rx*ry;vec3 pos=view*(rz*(a*s*sc)+p-vec3(0.,.53,0.));normal=normalize(view*rz*n);gl_Position=vec4(pos.x/(3.*aspect)*zoom,pos.y/3.*zoom,-pos.z/9.,1.);}`;
const FS=`precision mediump float;uniform vec3 color;uniform bool picking;varying vec3 normal;void main(){float light=.42+.58*max(0.,dot(normalize(normal),normalize(vec3(-.7,1.,1.5))));gl_FragColor=vec4(picking?color:color*light,1.);}`;
const QSCALE=5/32767;
export function MuscleBody({counts,selected,onSelect,motion,available,pain,painMode,skeleton}:any){
 const canvas=useRef<HTMLCanvasElement>(null),props=useRef<any>({}),[status,setStatus]=useState('loading'),[zoom,setZoom]=useState(1);
 props.current={counts,selected,onSelect,motion,available,pain,painMode,skeleton,zoom};
 useEffect(()=>{
 const c=canvas.current!;const gl=c.getContext('webgl',{antialias:true,preserveDrawingBuffer:true});
 if(!gl){setStatus('error');return}
 let dead=false,manifest:MPart[]=[],visible:{id:string}[]=[];
 function shader(type:number,src:string){const sh=gl!.createShader(type)!;gl!.shaderSource(sh,src);gl!.compileShader(sh);if(!gl!.getShaderParameter(sh,gl!.COMPILE_STATUS))throw new Error('Shader failed');return sh}
 const prog=gl.createProgram()!;gl.attachShader(prog,shader(gl.VERTEX_SHADER,VS));gl.attachShader(prog,shader(gl.FRAGMENT_SHADER,FS));gl.linkProgram(prog);gl.useProgram(prog);
 const u=(n:string)=>gl.getUniformLocation(prog,n),la=gl.getAttribLocation(prog,'a'),ln=gl.getAttribLocation(prog,'n');
 gl.enable(gl.DEPTH_TEST);
 // unit sphere (joint markers), non-interleaved
 const sv:number[]=[],sn:number[]=[];const vv=(a:number,b:number)=>[Math.sin(a)*Math.cos(b),Math.cos(a),Math.sin(a)*Math.sin(b)];
 for(let i=0;i<22;i++)for(let j=0;j<28;j++){const a=i*Math.PI/22,b=j*Math.PI*2/28,da=Math.PI/22,db=Math.PI*2/28;for(const x of [vv(a,b),vv(a+da,b),vv(a+da,b+db),vv(a,b),vv(a+da,b+db),vv(a,b+db)]){sv.push(...x);sn.push(...x)}}
 const spherePos=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,spherePos);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(sv),gl.STATIC_DRAW);
 const sphereNrm=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,sphereNrm);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(sn),gl.STATIC_DRAW);
 let meshV:WebGLBuffer|null=null,meshI:WebGLBuffer|null=null;
 fetch('./muscles.bin').then(r=>{if(!r.ok)throw new Error('asset');return r.arrayBuffer()}).then(buf=>{
  if(dead)return;const dv=new DataView(buf);const jl=dv.getUint32(0,true);
  manifest=JSON.parse(new TextDecoder().decode(new Uint8Array(buf,4,jl)));
  const raw=buf.slice(4+jl);
  meshV=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,meshV);gl.bufferData(gl.ARRAY_BUFFER,raw,gl.STATIC_DRAW);
  meshI=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,meshI);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,raw,gl.STATIC_DRAW);
  setStatus('ready');
 }).catch(()=>{if(!dead)setStatus('error')});
 let yaw=.2,pitch=-.04,last=performance.now(),drag:any=null,moved=false;
 function colorFor(id:string,base:number[],pr:any,pick:boolean,idx:number){
  if(pick)return [(idx+1)/255,0,0];
  let color=base;const n=pr.counts[id]||0;
  if(pr.painMode){color=pr.pain.includes(id)?[.85,.12,.12]:base.map((x:number)=>x*.4+.58)}
  else if(pr.available&&n){const t=n/Math.max(1,...Object.values(pr.counts).map(Number));color=[.94-.2*t,.69-.58*t,.62-.5*t]}
  else if(!pr.available)color=[.82,.79,.76];
  if(id&&id===pr.selected)color=color.map((x:number)=>Math.min(1,x*1.2));
  return color;
 }
 function draw(pick=false){
  if(dead)return;const pr=props.current;const rect=c.getBoundingClientRect();const d=Math.min(window.devicePixelRatio||1,2);
  if(c.width!==Math.round(rect.width*d)||c.height!==Math.round(rect.height*d)){c.width=Math.round(rect.width*d);c.height=Math.round(rect.height*d)}
  gl!.viewport(0,0,c.width,c.height);gl!.clearColor(pick?0:.985,pick?0:.981,pick?0:.974,1);gl!.clear(gl!.COLOR_BUFFER_BIT|gl!.DEPTH_BUFFER_BIT);
  gl!.uniform1f(u('yaw'),yaw);gl!.uniform1f(u('pitch'),pitch);gl!.uniform1f(u('aspect'),c.width/c.height);gl!.uniform1f(u('zoom'),pr.zoom);gl!.uniform1i(u('picking'),pick?1:0);
  visible=[];let idx=0;
  if(!pr.skeleton){
   gl!.uniform1f(u('sc'),1);
   for(const part of joints){
    gl!.bindBuffer(gl!.ARRAY_BUFFER,spherePos);gl!.enableVertexAttribArray(la);gl!.vertexAttribPointer(la,3,gl!.FLOAT,false,0,0);
    gl!.bindBuffer(gl!.ARRAY_BUFFER,sphereNrm);gl!.enableVertexAttribArray(ln);gl!.vertexAttribPointer(ln,3,gl!.FLOAT,false,0,0);
    gl!.uniform3fv(u('color'),colorFor(part.id,part.id==='head'?[.75,.68,.62]:[.72,.66,.61],pr,pick,idx));
    gl!.uniform3fv(u('p'),part.p);gl!.uniform3fv(u('s'),part.s);gl!.uniform1f(u('rot'),part.r||0);
    gl!.drawArrays(gl!.TRIANGLES,0,sv.length/3);visible.push({id:part.id});idx++;
   }
  }
  if(meshV&&meshI){
   gl!.bindBuffer(gl!.ARRAY_BUFFER,meshV);gl!.bindBuffer(gl!.ELEMENT_ARRAY_BUFFER,meshI);
   gl!.uniform3fv(u('p'),[0,0,0]);gl!.uniform3fv(u('s'),[1,1,1]);gl!.uniform1f(u('rot'),0);gl!.uniform1f(u('sc'),QSCALE);
   manifest.forEach(mp=>{
    if(pr.skeleton?!mp.bone:mp.bone)return;
    const base=mp.bone?[.93,.9,.84]:(mp.region?[.66,.3,.27]:[.63,.35,.32]);
    gl!.uniform3fv(u('color'),colorFor(mp.region,base,pr,pick,idx));
    gl!.vertexAttribPointer(la,3,gl!.SHORT,false,0,mp.vo);
    gl!.enableVertexAttribArray(la);
    gl!.vertexAttribPointer(ln,3,gl!.BYTE,true,0,mp.vo+mp.nv*6);
    gl!.enableVertexAttribArray(ln);
    gl!.drawElements(gl!.TRIANGLES,mp.ni,gl!.UNSIGNED_SHORT,mp.io);
    visible.push({id:mp.region});idx++;
   });
  }
 }
 const down=(e:PointerEvent)=>{drag=[e.clientX,e.clientY];moved=false;c.setPointerCapture(e.pointerId)};
 const move=(e:PointerEvent)=>{if(!drag)return;const dx=e.clientX-drag[0],dy=e.clientY-drag[1];if(Math.abs(dx)+Math.abs(dy)>2)moved=true;yaw+=dx*.012;pitch=Math.max(-.7,Math.min(.7,pitch+dy*.008));drag=[e.clientX,e.clientY]};
 const up=(e:PointerEvent)=>{drag=null;if(moved)return;draw(true);const r=c.getBoundingClientRect(),pixel=new Uint8Array(4);
  gl!.readPixels(Math.floor((e.clientX-r.left)*c.width/r.width),Math.floor((r.bottom-e.clientY)*c.height/r.height),1,1,gl!.RGBA,gl!.UNSIGNED_BYTE,pixel);
  const p=visible[pixel[0]-1];if(p&&p.id&&regions.some(r=>r.id===p.id))props.current.onSelect(p.id);draw()};
 const key=(e:KeyboardEvent)=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();yaw+=e.key==='ArrowLeft'?-.13:e.key==='ArrowRight'?.13:0;pitch=Math.max(-.7,Math.min(.7,pitch+(e.key==='ArrowUp'?-.08:e.key==='ArrowDown'?.08:0)))}};
 c.addEventListener('pointerdown',down);c.addEventListener('pointermove',move);c.addEventListener('pointerup',up);c.addEventListener('keydown',key);
 const loop=(now:number)=>{const dt=Math.min(.05,(now-last)/1000);last=now;if(props.current.motion&&!drag&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches)yaw+=dt*.09;draw();if(!dead)requestAnimationFrame(loop)};requestAnimationFrame(loop);
 return()=>{dead=true;c.removeEventListener('pointerdown',down);c.removeEventListener('pointermove',move);c.removeEventListener('pointerup',up);c.removeEventListener('keydown',key)};
 },[]);
 return <div className="orbit-wrap">{status==='error'?<p>The 3D muscular anatomy could not be loaded on this device or connection. The front and back diagrams still work.</p>:<><canvas ref={canvas} className="orbit-body" tabIndex={0} aria-label="Realistic muscular 3D anatomy using BodyParts3D meshes. Drag to rotate, arrow keys to orbit, tap a muscle or joint to select its region."/><p className="fine">Drag to orbit · Tap a muscle or joint · Arrow keys rotate{status==='loading'?' · loading anatomy…':''}</p><label className="zoom">Zoom <input type="range" min="0.8" max="1.2" step="0.05" value={zoom} onChange={e=>setZoom(Number(e.target.value))}/></label><p className="fine">Muscle and bone meshes: BodyParts3D, (c) The Database Center for Life Science, licensed CC BY 4.0. Joint markers are simplified. Regional colours remain research, demo or self-reported layers - not a diagnosis.</p></>}</div>
}
