import React,{useState} from 'react';
import {FileCard,Group,Closing,ChoiceRow,Callout,TextLink,FileButton} from './ui';
import {sports,sources,regions,demo,evidence,exfreq} from './data';
import {Anatomy} from './Anatomy';
import {MuscleBody} from './MuscleBody';
import {LogoMark} from './LogoMark';
import {SportMarquee} from './SportMarquee';
import {MotionTabs} from './MotionTabs';
import './style.css';
const options=(a:string[])=>a.map(value=>({value,label:value}));
const source=(id:string)=>sources.find(s=>s.id===id)!;
function Cite({id}:{id:string}){const s=source(id);return <TextLink href={s.url}>{s.title}</TextLink>}
const verb=(s:string)=>({Running:'run',Swimming:'swim',Cycling:'ride'}[s]||'play or train');
export function App(){
 const [sport,setSport]=useState('HYROX'),[role,setRole]=useState('All'),[gender,setGender]=useState('All'),[mode,setMode]=useState('Published cohort'),[history,setHistory]=useState('None selected'),[selected,setSelected]=useState('knee'),[back,setBack]=useState(false),[orbit,setOrbit]=useState(false),[skeleton,setSkeleton]=useState(false),[motion,setMotion]=useState(true),[tab,setTab]=useState('Evidence');
 const [qFreq,setQFreq]=useState(''),[qDur,setQDur]=useState(''),[qPain,setQPain]=useState(''),[painRegions,setPainRegions]=useState<string[]>([]),[qTab,setQTab]=useState('How often'),[showResults,setShowResults]=useState(false);
 const painMode=mode==='Your pain report';
 const synthetic=mode==='Fictional demo';
 const available=painMode||synthetic||(sport==='HYROX'&&gender==='All'&&role==='All');
 const rows=demo.filter(x=>x.sport===sport&&(role==='All'||x.role===role)&&(gender==='All'||x.gender===gender));
 const counts=Object.fromEntries(regions.map(r=>[r.id,!available?0:synthetic?rows.filter(x=>x.region===r.id).length:r.n]));
 const total=available?(synthetic?rows.length:63):0;
 const active=regions.find(r=>r.id===selected)!;
 const selectedCount=counts[selected];
 const claims=evidence(sport,selected,history);
 const answered=!!(qFreq&&qDur&&(qPain==='no'||(qPain==='yes'&&painRegions.length>0)));
 const modes=['Published cohort','Fictional demo',...(painRegions.length?['Your pain report']:[])];
 function reset(){setSport('HYROX');setRole('All');setGender('All');setMode('Published cohort');setHistory('None selected');setSelected('knee');setBack(false);setOrbit(false);setSkeleton(false);setMotion(true);setTab('Evidence');setQFreq('');setQDur('');setQPain('');setPainRegions([]);setQTab('How often');setShowResults(false)}
 function reveal(){if(!answered)return;setShowResults(true);setOrbit(true);if(painRegions.length){setMode('Your pain report');setSelected(painRegions[0])}}
 function togglePain(id:string){setPainRegions(p=>p.includes(id)?p.filter(x=>x!==id):[...p,id])}
 return <FileCard>
 <header className="hero"><LogoMark/><h1>Understand the athlete. Explore the anatomy.</h1><p className="fact">Athlete Atlas / working prototype / 10 activities</p><p className="intro">Explore regional injury patterns, previous-injury associations and supervised conditioning. This is a research explorer, not an individual injury predictor.</p></header>
 <div className="intro-line"><span className="eyebrow">01 / Pick your sport</span><button className="reset file-hover-underline" onClick={reset}>Reset explorer</button></div>
 <SportMarquee label="Sport or activity" sports={Object.keys(sports)} value={sport} onChange={(s:string)=>{setSport(s);setRole('All');setShowResults(false)}}/>
 <div className="intro-line"><span className="eyebrow">02 / Answer three quick questions</span></div>
 <p className="fine">Your answers stay in this page on your device. Nothing is saved, sent or shared. They shape what the map shows you; they never become a risk score.</p>
 <MotionTabs label="About your routine" tabs={['How often','How long','Any pain']} value={qTab} onChange={setQTab}>
  {qTab==='How often'&&<ChoiceRow label={`How often do you ${verb(sport)} each week?`} options={options(['1-2 times','3-4 times','5+ times'])} value={qFreq} onChange={setQFreq}/>}
  {qTab==='How long'&&<ChoiceRow label="How long is a typical session?" options={options(['Under 30 min','30-60 min','60-90 min','Over 90 min'])} value={qDur} onChange={setQDur}/>}
  {qTab==='Any pain'&&<div>
   <ChoiceRow label="Any current or recent pain?" options={options(['No pain','Yes - mark where'])} value={qPain} onChange={(v:string)=>{setQPain(v);if(v==='No pain')setPainRegions([])}}/>
   {qPain==='Yes - mark where'&&<><p className="fine">Tap every region where you feel pain. This only draws your own report on the map - it is not a diagnosis, and nothing leaves this page.</p>
   <div className="pain-grid">{regions.map(r=><button key={r.id} type="button" className={`file-button pain-chip ${painRegions.includes(r.id)?'on':''}`} aria-pressed={painRegions.includes(r.id)} onClick={()=>togglePain(r.id)}>{r.name}</button>)}</div></>}
  </div>}
 </MotionTabs>
 <div className="reveal-row"><button className="reveal-button" disabled={!answered} onClick={reveal}>{answered?'Show my anatomy map':'Answer the three questions above'}</button>{answered&&!showResults&&<span className="fine">Your summary: {sport} · {qFreq} a week · {qDur} a session · {qPain==='no'?'no pain reported':'pain in '+painRegions.length+' region'+(painRegions.length>1?'s':'')}</span>}</div>
 {showResults&&<div className="tab-content">
 <div className="intro-line"><span className="eyebrow">03 / Your map</span></div>
 <div className="filter-grid"><ChoiceRow label="Playing role / event type" options={options(['All',...sports[sport]])} value={role} onChange={setRole}/><ChoiceRow label="Gender grouping in demo" options={options(['All','Women','Men','Nonbinary','Not specified'])} value={gender} onChange={setGender}/></div>
 <p className="fine">Coverage starts with cricket, badminton, running and HYROX. The ten activities are a starting set, not a global popularity ranking. Gender identity is not inferred from biological sex in a study.</p>
 <ChoiceRow label="Data behind the colours" options={options(modes)} value={mode} onChange={setMode}/>
 <div className={`data-banner ${synthetic?'demo':''} ${painMode?'demo':''}`} role="status"><strong>{painMode?'YOUR REPORTED PAIN - NOT A MEASUREMENT':synthetic?'FICTIONAL DEMO DATA':available?'PUBLISHED HYROX COHORT':'NO MATCHED REGIONAL DATA'}</strong><p>{painMode?`Red marks the ${painRegions.length===1?'region':'regions'} you reported pain in (${painRegions.map(id=>regions.find(r=>r.id===id)!.name).join(', ')}). This is your own note on an anatomy illustration, not a diagnosis, screening result or injury probability. A clinician assesses pain.`:(synthetic?`${total} fictional injury events match these filters. These invented records demonstrate the interface only. They are not sports statistics, athlete records or a prediction.`:available?'63 injury episodes among 89 HYROX athletes over 12 weeks, December 2025 to March 2026. All injuries reported by this cohort, not just HYROX-attributed injuries. Counts, not personal risk.':'No curated regional counts match this sport × gender × role selection. Grey means unavailable, not zero injury risk. Use Fictional demo to test filters, or reset to HYROX / All / All for published counts.')}</p>{available&&!synthetic&&!painMode&&<Cite id="hyrox"/>}</div>
 <div className="explorer">
 <section className="map-panel" aria-label="Interactive anatomy">
 <div className="panel-top"><span className="eyebrow">04 / Select a region</span><span className="data-pill">{painMode?'Your report':synthetic?'Fictional':available?'Published':'Unavailable'}</span></div>
 <div className="map-controls"><FileButton selected={!back&&!orbit} onClick={()=>{setBack(false);setOrbit(false)}}>Front</FileButton><FileButton selected={back&&!orbit} onClick={()=>{setBack(true);setOrbit(false)}}>Back</FileButton><FileButton selected={orbit} onClick={()=>setOrbit(!orbit)}>3D muscles</FileButton><FileButton selected={skeleton} onClick={()=>setSkeleton(!skeleton)}>Bones</FileButton><FileButton selected={motion} onClick={()=>setMotion(!motion)}>{motion?'Pause motion':'Play motion'}</FileButton></div>
 {orbit?<MuscleBody counts={counts} selected={selected} onSelect={setSelected} skeleton={skeleton} motion={motion} available={available&&!painMode} pain={painRegions} painMode={painMode}/>:<Anatomy counts={counts} selected={selected} onSelect={setSelected} back={back} skeleton={skeleton} motion={motion} available={available&&!painMode} pain={painRegions} painMode={painMode}/>}
 <div className="legend"><span>{painMode?'Not reported':'Fewer episodes'}</span><span className="ramp"/><span>{painMode?'Pain you reported':'More episodes'}</span></div>
 <p className="fine">{painMode?'Your marks only. ':synthetic?'Fictional counts only. ':available?'Published counts only. ':'No frequency colours. '}Red intensity is relative to the largest count in this view. It is not severity or probability. Both sides share one regional total; no laterality is available. Bones and muscles are an illustrative layer.</p>
 </section>
 <section className="detail-panel" aria-label="Selected region details" aria-live="polite">
 <div className="eyebrow">05 / Region detail</div><h2>{active.name}</h2>
 <div className="count"><strong>{available&&!painMode?selectedCount:'—'}</strong><div>{painMode?<><b>{painRegions.includes(selected)?'You reported pain here':'No pain reported here'}</b><br/>A reported location is not a measured injury.</>:available?<><b>{synthetic?'fictional':'published'} episodes</b><br/>{selectedCount} of {total} total injury episodes ({(selectedCount/total*100).toFixed(1)}%)</>:<b>No matched frequency data</b>}</div></div>
 {!synthetic&&available&&!painMode&&<p className="fine">55 of 63 episodes fall in mapped regions; 8 other/unspecified episodes are not placed. The denominator includes all 63.</p>}
 <p>{active.examples}</p>
 <ChoiceRow label="Details" options={options(['Evidence','Conditioning','Rehab boundaries'])} value={tab} onChange={setTab}/>
 {tab==='Evidence'&&<div className="tab-content"><h3>Previous-injury scenario</h3><ChoiceRow label="Optional fictional history" options={options(['None selected','Hamstring strain','Ankle sprain','Other injury'])} value={history} onChange={setHistory}/><p className="fine">This scenario changes the reading notes, never the map counts. No personal health records are needed or saved.</p>{claims.map((c,i)=><div className="evidence-note" key={i}><p>{c.text}</p><Cite id={c.source}/></div>)}{history==='Other injury'&&<p>No history-specific model is available for this scenario.</p>}<p className="fine">Selected context: {sport} / {role} / {gender}. Linked research may use sex categories, not gender identity, and may not match the selected role. No gender multiplier or individual probability is applied.</p></div>}
 {tab==='Conditioning'&&<div className="tab-content"><h3>General strengthening examples</h3><p>These are examples from AAOS conditioning guides, not a personalized exercise plan or proof that they prevent every injury in this region. Frequencies below are the ones printed in the linked AAOS guide.</p>{active.ex.length?<><ul className="exercise-list">{active.ex.map(x=><li key={x}>{x}{exfreq[x]&&<span className="freq">{exfreq[x]}</span>}</li>)}</ul><p>{active.cue}</p>{painRegions.includes(selected)&&<Callout title="You reported pain in this region" tone="warning">Get pain assessed before loading this region. AAOS programs are built for use with a doctor or physiotherapist, and they say to stop if an exercise causes pain.</Callout>}<Cite id={active.source}/></>:<p>No generic exercise is suggested here. Head, neck, hand and finger injuries need a condition-specific assessment.</p>}<Callout title="Choose exercises with a clinician" tone="warning">AAOS recommends doctor or physiotherapist supervision. Do not exercise through pain. No sets, loads, return-to-sport dates or personalized progression are prescribed by this prototype.</Callout></div>}
 {tab==='Rehab boundaries'&&<div className="tab-content"><h3>Rehab is diagnosis-specific</h3><p>A region and a previous injury are not enough to choose rehabilitation. A sports clinician should assess the diagnosis, healing stage, symptoms, strength and sport demands before prescribing loading or return to play.</p><ul><li>Use the linked guide as a discussion aid, not clearance.</li><li>Exercise choices and progression depend on the actual injury and current assessment.</li><li>New or worsening symptoms are a reason to stop the activity and seek clinical advice.</li></ul>{active.source&&<Cite id={active.source}/>}<Callout title="Not for diagnosis or urgent decisions" tone="warning">This map cannot assess an acute injury, concussion, fracture or tendon rupture. Use appropriate medical care rather than a heat-map result.</Callout></div>}
 </section></div>
 </div>}
 <Group label="Every region is also a button" heading="Regional counts">
 <div className="region-list">{regions.map(r=><button key={r.id} onClick={()=>setSelected(r.id)} aria-pressed={selected===r.id} className={selected===r.id?'selected':''}><span className="file-hover-underline">{r.name}</span><b>{available&&!painMode?counts[r.id]:'N/A'}</b></button>)}</div><p className="fine">Counts are {synthetic?'fictional demo events':available?'from the single published HYROX cohort':'unavailable for this selection'}. Use keyboard Tab and Enter on the anatomy or these buttons. A small sample is not proof a region is safe.</p>
 </Group>
 <Group label="What this can and cannot do" heading="A useful explorer, not a clinical model">
 <div className="method-grid"><div><h3>Working now</h3><ul><li>Ten activity categories with role or event filters.</li><li>Clickable front/back anatomy, realistic muscular 3D view, motion and bone overlay.</li><li>One source-backed HYROX regional count map.</li><li>Separate, plainly labeled fictional filter demo and self-reported pain view.</li><li>Injury-history evidence notes and conditioning references.</li></ul></div><div><h3>Before individual prediction</h3><ul><li>Consent-governed longitudinal injury and exposure data.</li><li>Consistent outcomes, follow-up window and recurrence definitions.</li><li>A trained model with athlete-level temporal splits.</li><li>External validation, calibration and subgroup evaluation.</li><li>Clinical governance, privacy review and safe deployment.</li></ul></div></div>
 <Callout title="Anatomy view" tone="note">The 3D view uses real anatomical meshes from BodyParts3D ((c) The Database Center for Life Science, CC BY 4.0) for muscle and bone orientation, with simplified joint markers. It shows regional research counts, fictional demo data or your own pain marks - it never generates a diagnosis, medical clearance or injury probability.</Callout>
 <p>Research findings, demo records and your on-device answers stay separate. Changing a sport, role or gender does not manufacture missing clinical evidence. In published mode, unsupported combinations show no map rather than a guessed frequency.</p>
 </Group>
 <Group label="Research and provenance" heading="Read the evidence">
 {sources.map(s=><details className="source-row" key={s.id}><summary>{s.title}</summary><p>{s.note}</p><TextLink href={s.url}>Open source</TextLink></details>)}
 <details className="source-row"><summary>3D anatomy asset provenance</summary><p>Muscle and bone meshes: BodyParts3D, (c) The Database Center for Life Science, licensed under CC Attribution 4.0 International. Citation: Mitsuhashi N et al., Nucleic Acids Research 2009;37:D782-6 (PMID 18835852). Meshes were merged and compressed for this app; joint markers (head, elbows, hands, knees, ankles, feet) are simplified original geometry.</p><TextLink href="https://dbarchive.biosciencedbc.jp/en/bodyparts3d/download.html">BodyParts3D download and license</TextLink></details>
 <details className="source-row"><summary>Visual references and asset provenance</summary><p>Original vector and procedural anatomy authored for this prototype. Inspired by the interaction concept only; no models, textures, exercise illustrations or viewer code reused from the inspiration links.</p><TextLink href="https://sketchfab.com/3d-models/animated-full-human-body-anatomy-9b0b079953b840bc9a13f524b60041e4">Sketchfab anatomy reference</TextLink><br/><TextLink href="https://www.msdmanuals.com/home/multimedia/3dmodel/muscular-system">MSD muscular-system reference</TextLink></details>
 </Group>
 <Closing>Research checked 12 November 2026. Routine and pain answers live only in this page's temporary state - nothing is saved, transmitted or shared. Demo-only controls use temporary page state. No medical records collected, no backend, no trained prediction model.</Closing>
 </FileCard>
}
